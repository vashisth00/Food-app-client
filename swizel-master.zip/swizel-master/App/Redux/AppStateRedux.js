import { createReducer, createActions } from 'reduxsauce'
import Immutable from 'seamless-immutable'

const { Types, Creators } = createActions({
  firstLaunch: null
})

export const AppStateTypes = Types
export default Creators


export const INITIAL_STATE = Immutable({
  firstLaunch: true
})


// rehydration is complete
export const setFirstLaunch = (state: Object) =>
  state.merge({ firstLaunch: false })


export const reducer = createReducer(INITIAL_STATE, {
  [Types.FIRST_LAUNCH]: setFirstLaunch
})

export const isFirstLaunch = (state: Object) => (state.isFirstLaunch)
