// a library to wrap and simplify api calls
import apisauce from 'apisauce'

// our "constructor"
const create = (baseURL = 'http://192.168.137.1/swizel/api/') => {
  // ------
  // STEP 1
  // ------
  //
  // Create and configure an apisauce-based api object.
  //
  const api = apisauce.create({
    // base URL is read from the "constructor"
    baseURL,
    // here are some default headers
    headers: {
      'Cache-Control': 'no-cache'
    },
    // 10 second timeout...
    timeout: 10000
  })

  // ------
  // STEP 2
  // ------
  //
  // Define some functions that call the api.  The goal is to provide
  // a thin wrapper of the api layer providing nicer feeling functions
  // rather than "get", "post" and friends.
  //
  // I generally don't like wrapping the output at this level because
  // sometimes specific actions need to be take on `403` or `401`, etc.
  //
  // Since we can't hide from that, we embrace it by getting out of the
  // way at this level.
  //
  const loginUsingEmail = (username, password) => api.post('login' , { 'email' : username, 'password' : password , 'provider' : 'email' })

  const getRestaurants = (lat, lng) => api.get('restaurants/'+lat+'/'+lng)
  const getRestaurantsById = (restid) => api.get('restaurants/'+restid)

  const getCart = (authToken) => api.get('cart', {}, { headers: {'Authorization' : authToken}} )
  const addToCart = (itemid, authToken) => api.post('cart/'+itemid, {}, { headers: {'Authorization' : authToken}} )
  const removeFromCart = (itemid, authToken) => api.delete('cart/i'+itemid, {}, { headers: {'Authorization' : authToken}} )
  const confirmCart = (cartid, authToken) => api.get('cart/'+cartid+'/confirm', {}, { headers: {'Authorization' : authToken}} )
  const addAddress = (phone, address, city, state, pin, authToken) => api.post('user/address', { 'number' : phone, 'address' : address, 'city' : city, 'state' :state, 'pin' : pin }, { headers: {'Authorization' : authToken}} )
  const getOrders = (authToken) => api.get('orders', {}, { headers: {'Authorization' : authToken}} )

  const getDesserts = (lat, lng) => api.get('desserts/'+lat+'/'+lng)
  const getDessertsById = (restid) => api.get('desserts/'+restid)

  const getFCK = (lat, lng) => api.get('fck/'+lat+'/'+lng)
  const getFCKById = (restid) => api.get('fck/'+restid)

  const getUser = (authToken) => api.get('user', {}, { headers: {'Authorization' : authToken}} )
  const getMenuByRestId = (restid) => api.get('menu/'+restid)

  // ------
  // STEP 3
  // ------
  //
  // Return back a collection of functions that we would consider our
  // interface.  Most of the time it'll be just the list of all the
  // methods in step 2.
  //
  // Notice we're not returning back the `api` created in step 1?  That's
  // because it is scoped privately.  This is one way to create truly
  // private scoped goodies in JavaScript.
  //
  return {
    // a list of the API functions from step 2
    getRestaurants,
    getRestaurantsById,
    getDesserts,
    getDessertsById,
    getFCK,
    getFCKById,
    getMenuByRestId,
    loginUsingEmail,
    addToCart,
    getCart,
    getUser,
    removeFromCart,
    addAddress,
    confirmCart,
    getOrders
  }
}

// let's return back our create method as the default.
export default {
  create
}
