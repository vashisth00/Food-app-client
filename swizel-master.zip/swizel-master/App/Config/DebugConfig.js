export default {
  useFixtures: false,
  ezLogin: false,
  yellowBox: false,
  reduxLogging: __DEV__,
  includeExamples: __DEV__,
  useReactotron: __DEV__
}
