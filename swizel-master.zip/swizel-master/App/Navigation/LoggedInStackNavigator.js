import { StackNavigator } from 'react-navigation'
import VendorScreen from '../Containers/VendorScreen'
import ProfileScreen from '../Containers/ProfileScreen'
import RestaurantScreen from '../Containers/RestaurantScreen'
import LocationScreen from '../Containers/LocationScreen'
import HomeScreen from '../Containers/HomeScreen'
import FlowersCakeGiftsScreen from '../Containers/FlowersCakeGiftsScreen'
import DessertsScreen from '../Containers/DessertsScreen'
import styles from './Styles/NavigationStyles'

export default StackNavigator({
  VendorScreen: { screen: VendorScreen },
  RestaurantScreen: { screen: RestaurantScreen },
  LocationScreen: { screen: LocationScreen },
  HomeScreen: { screen: HomeScreen },
  FlowersCakeGiftsScreen: { screen: FlowersCakeGiftsScreen },
  DessertsScreen: { screen: DessertsScreen },
  ProfileScreen: { screen: ProfileScreen }
}, {
  headerMode: 'none',
  initialRouteName: 'HomeScreen',
  navigationOptions: {
    headerStyle: styles.header
  }
})