import { StackNavigator } from 'react-navigation'

import LaunchScreen from '../Containers/LaunchScreen'
import LoggedInStackNavigator from './LoggedInStackNavigator'
import NotLoggedInStackNavigator from './NotLoggedInStackNavigator'

import styles from './Styles/NavigationStyles'

const PrimaryNav = StackNavigator({
  
  LaunchScreen: { screen: LaunchScreen },
  LoggedInStack: { screen: LoggedInStackNavigator },
  NotLoggedInStack: { screen: NotLoggedInStackNavigator }
}, {
  headerMode: 'none',
  navigationOptions: {
    headerStyle: styles.header
  }
})

export default PrimaryNav
