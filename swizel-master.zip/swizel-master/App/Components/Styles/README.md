### Styles Folder
Component styles are separated from functionality.
