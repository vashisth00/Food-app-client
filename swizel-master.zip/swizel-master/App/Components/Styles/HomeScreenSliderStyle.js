import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    flex: 1
  },
  slider: {
  	flex: 1,
  	backgroundColor: "#000",
  	height: 256,
  	justifyContent: 'center',
  	alignItems: 'center'
  }, 
  sliderHeading: {
  	color: '#fff',
  	fontSize: 18
  },
  sliderSubLine: {
  	color: '#fff',
  	fontSize: 12
  }
})
