import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    height: 64,
    paddingTop: 24,
    paddingLeft: 16,
    paddingRight: 16,
    paddingBottom: 16,
    borderWidth: 1,
    backgroundColor: '#fff',
    borderColor: '#d6d7da'
  },
  logo : {
  	color: '#000',
  	fontSize: 18,
  	fontWeight: "600",
    position: "absolute",
    top: 25,
    left: 40
  },
  topButtonIcon:{
    fontSize: 32,
    marginRight: 8
  },
  topButtons: {
    position: "absolute",
    right: 8,
    top: 24,
    flexDirection: 'row'
  }
})
