import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { View, Text, TouchableOpacity } from 'react-native'
import { Images, Fonts } from '../Themes'
import Icon from 'react-native-vector-icons/EvilIcons';
import styles from './Styles/VendorBoxStyle'

export default class VendorBox extends Component {
  static propTypes = {
    navigation: PropTypes.object,
    data: PropTypes.any
  }

  days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
  today = false;

  constructor (props) {
    super(props)
    this.today = new Date();
  }

  render () {
    return (
      <View style={{ flex : 1, borderBottomWidth: 0.5, borderColor: "#d3d3d3" }}>
        <TouchableOpacity style={{flex : 1, flexDirection: 'row', backgroundColor: '#fff', padding: 16 }} onPress={() => { this.props.navigation != undefined && this.props.navigation.navigate('RestaurantScreen', { rest : this.props.data }) }}>
          <View style={{ backgroundColor: '#d3d3d3', height: 96  , width : 96, borderRadius: 48, marginRight: 16 }} />
          <View style={{ flex: 2, paddingRight: 8, paddingTop: 0 }}>
            <Text style={[Fonts.style.normal, { fontWeight: "700" }]} >{this.props.data.name}</Text>
            <Icon name="location" style={{ position : 'relative', top : 14 }}/>
            <View style={{ marginLeft: 16 }}>
            <Text style={[Fonts.style.description]} >{this.props.data.address}</Text>
            <Text style={[Fonts.style.description, { fontSize: 12, color: 'rgba(0,0,0,0.3)' }]} >{this.props.data.location}</ Text>
            </View>
            { this.props.navigation != undefined && 
            <Text style={[Fonts.style.description]} ><Icon name="clock" style={{marginRight: 8, marginTop : 8 }}/>  {this.props.data.timings[this.days[this.today.getDay()]][0]['open']} - {this.props.data.timings[this.days[this.today.getDay()]][0]['close']} </Text>
            }
          </View>
          <View style={{ flex: 1, paddingTop: 0 }}>
            <View style={{ flex : 1, alignItems : 'flex-end' }}>
            { this.props.dist && 
              `<Text style={ Fonts.style.h5 }>{this.props.data.dist}</Text>
              <Text>Kms</Text>`
            }
            </View>
          </View>
        </TouchableOpacity>
      </View>
    )
  }
}
