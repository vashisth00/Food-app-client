import React, { Component } from 'react'
// import PropTypes from 'prop-types';
import {  Text, View, ImageBackground } from 'react-native'
import styles from './Styles/HomeScreenSliderStyle'
import Swiper from 'react-native-swiper'
import { Images } from '../Themes'

const dotStyle = () => {
  return (
    <View 
      style={{ 
        borderColor: 'rgba(255,255,255,1)',
        borderWidth: 1,
        width: 5,
        height: 5,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 32
      }} 
    />
  )
}

const activeDot = () => {
  return (
    <View 
      style={{
        backgroundColor: '#fff',
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 32
      }} 
    />
  )
}

class HomeScreenSlider extends Component {

  render () {
    return (
      <Swiper loop={true} style={{ height: 256}}  dot={dotStyle()} activeDot={activeDot()}>
        <ImageBackground source={Images.header1} style={ styles.slider }>
          <Text style={ styles.sliderHeading }> Slider 1 </Text>
        </ImageBackground>
        <ImageBackground source={Images.header2} style={ styles.slider }>
          <Text style={ styles.sliderHeading }> Slider 2 </Text>
        </ImageBackground>
        <ImageBackground source={Images.header3} style={ styles.slider }>
          <Text style={ styles.sliderHeading }> Slider 3 </Text>
        </ImageBackground>
      </Swiper>
    )
  }
}

export default HomeScreenSlider