import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { View, Text, Modal, ScrollView,TouchableOpacity , Image, TextInput } from 'react-native'
import styles from './Styles/TopBarStyle'
import Icon from 'react-native-vector-icons/SimpleLineIcons';
import { Images } from '../Themes'

export class TopBar extends Component {
  
  static propTypes = {
    navigation: PropTypes.object,
    heading: PropTypes.string,
    search: PropTypes.boolean
  }

  constructor () {
    super()
    this.state = {
      showModal: false
    }
  }

  toggleModal = () => {
    this.setState({ showModal: !this.state.showModal })
  }


  render () {
    return (
      <View style={{ height: 64, elevation: 1, backgroundColor: '#fff', padding: 12, paddingTop : 24, paddingBottom: 8, borderColor : "#C8CFD6", borderBottomWidth: 0.5 }}>
        <View style={{ flexDirection: 'row', flex: 1 }}>
          <TouchableOpacity style={{ fontSize : 24 }} onPress={() => {this.props.navigation.goBack()}}><Text><Icon style={{ fontSize : 10, marginRight: 8, marginTop: 8 }} name="arrow-left" />Back </Text></TouchableOpacity>
          <Text style={{ lineHeight: 20, marginLeft: 16, fontWeight: "700", flex: 1 }}>{this.props.heading}</Text>
          
        </View>
      </View>
    )
  }
}
