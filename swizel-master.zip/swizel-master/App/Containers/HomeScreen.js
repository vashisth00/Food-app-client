import React, { Component } from 'react'
import { View, Image, ScrollView, Text, TextInput, TouchableOpacity, ImageBackground, Dimensions } from 'react-native'
import { Images } from '../Themes'
import Icon from 'react-native-vector-icons/SimpleLineIcons';
import { connect } from 'react-redux'
import HomeScreenSlider from '../Components/HomeScreenSlider'
import BottomNavigation, { Tab } from 'react-native-material-bottom-navigation'
// Add Actions - replace 'Your' with whatever your reducer is called :)
// import YourActions from '../Redux/YourRedux'

// Styles
import styles from './Styles/HomeScreenStyle'

const { wWidth, wHeight } = Dimensions.get('window')

class HomeScreen extends Component {

  constructor (props) {
    super(props)
    this.state = {
      location : {
        latitude : 26.842222899999996,
        longitude : 75.5614799
      }
    }
  }
  componentDidMount () {

  }

  render () {
    return (
      <View style={{ flex: 1 }}>
          <View style={{ height: 64, backgroundColor: '#fff', padding: 12, paddingTop : 32, paddingBottom: 8, borderColor : "#C8CFD6", borderBottomWidth: 0.5, elevation: 2 }}>
            <View style={{ flexDirection: 'row', flex: 1 }}>
              <Image source={Images.logo} style={{ height: 24, width : 66 }}/>
              <Icon name="user" style={{ fontSize : 18, position: 'absolute', right: 0, top: 4 }}></Icon>
            </View>
          </View>
          <ScrollView style={{ flex: 1, flexDirection : 'column', paddingTop: 8, marginBottom: 62  }}>
            <HomeScreenSlider />
            <View style={{ position: 'relative', backgroundColor: '#fff', top: -42, marginRight: 32, marginLeft: 32, borderRadius: 8 }}>
              <View style={{ backgroundColor: '#fff', flex: 1, borderColor: '#fd667b', borderTopLeftRadius: 8, borderTopRightRadius: 8, padding: 8, paddingRight: 0, flexDirection: 'row' }}>
                <Icon name="location-pin" style={{ color: '#000', fontSize : 20, lineHeight: 26 }} onPress={() => {this.props.navigation.navigate('LocationScreen')}}></Icon>
                <View style={{ paddingTop: 8, paddingLeft: 4, flexDirection: 'row' }}>
                  <Text style={{ fontSize: 12, color: '#000'}}> DLF City 5, Gurgaon </Text>
                </View>
              </View>
              <View style={{ backgroundColor: '#fd667b', flex: 2, borderBottomLeftRadius: 8, borderBottomRightRadius: 8, paddingLeft: 8 }}>
                <TextInput underlineColorAndroid="transparent" placeholder="Search dishes, restaurants..." style={{ color: '#fff' }} placeholderTextColor="rgba(255,255,255,0.75)"/>
                <Icon name="magnifier" style={{ color: '#fff', fontSize : 16, position: "absolute", right: 16, top: 14 }} />
              </View>
            </View>
            <View style={{ flex : 1, flexDirection: 'row', marginTop: -32}}>
              <TouchableOpacity style={{flex : 2 }} onPress={() => { this.props.navigation.navigate('VendorScreen') }}>
                <ImageBackground source={Images.orderFood} style={{ height: 192, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' , margin: 8 }}>
                  <Text style={{ color: '#fff', fontSize: 18 }}> Order Food </Text>
                </ImageBackground>
              </TouchableOpacity>
              <View style={{ flex : 1 }}>
                <TouchableOpacity style={{flex : 1 }} onPress={() => { this.props.navigation.navigate('DessertsScreen') }}>
                  <ImageBackground source={Images.dessert} style={{ backgroundColor: "#000", height: 92, justifyContent: 'center', alignItems: 'center' , margin: 8, marginLeft: 4, marginBottom: 4}}>
                    <Text style={{ color: '#fff', fontSize: 14 }}> Desserts </Text>
                  </ImageBackground>
                </TouchableOpacity>
                <TouchableOpacity style={{flex : 1 }}>
                  <ImageBackground source={Images.bookTable} style={{ backgroundColor: "#000", height: 92, justifyContent: 'center', alignItems: 'center' , margin: 8, marginLeft: 4, marginTop: 4}}>
                    <Text style={{ color: '#fff', fontSize: 14 }}> Book Table </Text>
                  </ImageBackground>
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity style={{ flex : 1, flexDirection: 'row'}} onPress={() => { this.props.navigation.navigate('FlowersCakeGiftsScreen') }}>
              <ImageBackground source={Images.gifts} style={{ flex : 1, backgroundColor: "#000", height: 192, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' , margin: 8, marginTop: 4 }}>
                <Text style={{ color: '#fff', fontSize: 18 }}> Flowers, Cakes & Gifts </Text>
              </ImageBackground>
            </TouchableOpacity>
            <View style={{ flex : 1, flexDirection: 'row'}}>
              <ImageBackground source={Images.venue} style={{ flex : 1, backgroundColor: "#000", height: 192, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' , margin: 8, marginTop: 4 }}>
                <Text style={{ color: '#fff', fontSize: 18 }}> Venue Booking </Text>
              </ImageBackground>
              <ImageBackground source={Images.specials} style={{ flex : 1, backgroundColor: "#000", height: 192, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' , margin: 8, marginTop: 4 }}>
                <Text style={{ color: '#fff', fontSize: 18 }}> Specials </Text>
              </ImageBackground>
            </View>
          </ScrollView>
          <BottomNavigation
            labelColor="#d3d3d3"
            rippleColor="#d3d3d3"
            activeLabelColor="#2c2c2c"
            shifting={false}
            style={{
              position: 'absolute',
              left: 0,
              bottom: 0,
              right: 0,
              borderColor: '#C8CFD6',
              borderTopWidth: 1
            }}
          >
            <Tab label="Home" icon={<Icon size={18} name="home" />} />
            <Tab label="Previous Orders" icon={<Icon size={18} name="reload" />} />
            <Tab label="Saved Places" icon={<Icon size={18} name="note" />} />
            <Tab label="Profile" icon={<Icon size={18} name="user" />} onPress={() => { this.props.navigation.navigate('ProfileScreen') }}/>
          </BottomNavigation>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen)
