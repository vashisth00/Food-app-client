import React, { Component } from 'react'
import { ScrollView, Picker, Text, KeyboardAvoidingView, TouchableOpacity, Image, TextInput, View,Modal, Dimensions, AsyncStorage } from 'react-native'
import { connect } from 'react-redux'
import { TabNavigator } from 'react-navigation'
// Add Actions - replace 'Your' with whatever your reducer is called :)
// import YourActions from '../Redux/YourRedux'
import { TopBar } from '../Components/TopBar'
import VendorBox from '../Components/VendorBox'
import { Images, Fonts } from '../Themes'
import Icon from 'react-native-vector-icons/SimpleLineIcons';
import API from '../Services/Api'
import Loading from '../Components/Loading'


// Styles
import styles from './Styles/RestaurantScreenStyle'

const { wWidth, wHeight } = Dimensions.get('window')

class RestaurantScreen extends Component {
  constructor (props) {
    super(props)
    this.state = {
      showModal: false,
      showModalAddress: false,
      showModalPlaced: false,
      longitude: false,
      latitude: false,
      error: false,
      loading: true,
      data: [],
      rest : [],
      cat : [],
      cart : [],
      cartItems : 0,
      cartCost: 0
    }
    let rest =  this.props.navigation.state.params.rest;
    this.api = API.create()
    this.api.getMenuByRestId(rest.id).then((res) =>{
      let data = res.data;
      if (data.status != 200)
        this.setState({ loading : false, error : true })
      else {
        data = data.data;
        var categories = [];
        for (var i = 0; i < data.length; i++) {
          var index = categories.indexOf(data[i].category);
          if (index == -1){
            categories.push(data[i].category);
          }
          data[i].qty = 0;
        }
        this.setState({ error : false, cat: categories, data: data, loading : false, rest : this.props.navigation.state.params.rest })
      }
    }).catch((err) => {

    })
    this.api.getCart(this.props.authtoken).then((res) => {
      let data = res.data
      
      if (data.status == 200){
        let rid = data.data.map((cart) => { return cart.restaurant })
        let ind = rid.indexOf(this.state.rest.id)
        let cart = data.data[ind]
        this.state.cartItems = 0
        for (var i = 0 ; i < cart.items.length ; i++){
          var ids = this.state.data.map((item) => { return item.id });
          var index = ids.indexOf(cart.items[i].id);
          if (index >= 0){
            this.state.data[index].qty = cart.items[i].qty
            this.state.cartItems += parseInt(cart.items[i].qty)
            this.state.cartCost += cart.items[i].qty * cart.items[i].price
          }
          // console.tron.log(cart.items[i].qty)
          // console.tron.log(this.state.data[index].qty)
          console.tron.log(this.state)
        }
        this.setState({  cart : cart, data : this.state.data, cartItems : this.state.cartItems, cartCost : this.state.cartCost })
      }
    })
  }

  toggleModal = () => {
    this.setState({ showModal: !this.state.showModal })
  }

  toggleModalAddress = () => {
    this.setState({ showModalAddress : !this.state.showModalAddress })
  }


  toggleModalPlaced = () => {
    this.setState({ loading : !this.state.loading })
    this.api.confirmCart(this.state.cart.order_id, this.props.authToken).then((res) => {
      this.setState({ loading : false, showModalPlaced : !this.state.showModalPlaced })
    })
  }

  closeAllModal = () => {
    this.setState({ showModalPlaced : false, showModalAddress : false, showModal: false })
    for (var i= 0 ; i < this.state.data.length ; i++){
      this.state.data[i].qty  = 0;
    }
    this.setState({ data : this.state.data, cartItems: 0, cartCost: 0 })
  }

  addToCart = (itemid) => {
    this.api.addToCart(itemid, this.props.authtoken).then((res) => {
      if (res.data.status == 202){
        let cart = res.data.data[0]
        console.tron.log(cart)
        this.state.cartItems = 0
        for (var i = 0 ; i < cart.items.length ; i++){
          var ids = this.state.data.map((item) => { return item.id });
          var index = ids.indexOf(cart.items[i].id);
          if (index >= 0){
            this.state.data[index].qty = cart.items[i].qty
            this.state.cartItems += cart.items[i].qty
            this.state.cartCost += cart.items[i].qty * cart.items[i].price
          }
          console.tron.log(cart.items[i].qty)
          console.tron.log(this.state.data[index].qty)
          console.tron.log(this.state)
        }
        this.setState({  cart : cart, data : this.state.data, cartItems : this.state.cartItems, cartCost : this.state.cartCost })
      }
    })
  }

  removeFromCart = (itemid) => {
    this.api.removeFromCart(itemid, this.props.authtoken).then((res) => {
      if (res.data.status == 202){
        let cart = res.data.data[0]
        console.tron.log(cart)
        this.state.cartItems = 0
        for (var i = 0 ; i < cart.items.length ; i++){
          var ids = this.state.data.map((item) => { return item.id });
          var index = ids.indexOf(cart.items[i].id);
          if (index >= 0){
            this.state.data[index].qty = cart.items[i].qty
            this.state.cartItems += cart.items[i].qty
            this.state.cartCost += cart.items[i].qty * cart.items[i].price
          }
          console.tron.log(cart.items[i].qty)
          console.tron.log(this.state.data[index].qty)
          console.tron.log(this.state)
        }
        this.setState({  cart : cart, data : this.state.data, cartItems : this.state.cartItems, cartCost : this.state.cartCost })
      }
    })
  }

  renderMenuItem = (cat, cart) => {
    return ( this.state.data.map( (item) => {
      return (cart != 'true' || item.qty > 0) && (
          <View style={{backgroundColor : '#fff', padding: 16, paddingTop: 24, paddingLeft : 52, borderBottomWidth : 1, borderColor : "#d3d3d3"}}>
            <Icon name="cup" style={{ color: '#fe5b3c', position: 'absolute', top : 21, left : 16, fontSize : 24 } }/> 
            <View style={{flex: 1, flexDirection : 'row'}}>
              <View style={{ flex : 3 }}>
                <Text style={[ Fonts.style.normal,{ fontWeight: '400', color: "#000" }]} >{ item.item }</Text>
                <Text style={[ Fonts.style.description ]} >Test description </Text>
                <Text style={[ Fonts.style.description ]} >Rs. { item.price }</Text>
              </View>
              <View style={{ flex : 1, justifyContent: 'center',alignItems: 'center', flexDirection : 'row'}}>
                <TouchableOpacity onPress={ () => { this.removeFromCart(item.id) } }>
                  <Icon name="minus" style={{ color: '#fd667b', fontSize : 24, marginRight: 16 }} />
                </TouchableOpacity>
                <Text> { item.qty } </Text>
                <TouchableOpacity onPress={ () => { this.addToCart(item.id) } }>
                  <Icon name="plus" style={{ color: '#fd667b', fontSize : 24, marginLeft : 16 }} />
                </TouchableOpacity>
              </View>
            </View>
          </View>   
        )
    } ) )
  }

  render () {
    return (
      <View style={[styles.container]}>
        <Loading loading={this.state.loading} search={false}/>
        <View style={{ height: 64,  backgroundColor: '#fff', padding: 12, paddingTop : 24, paddingBottom: 0 }}>
          <View style={{ flexDirection: 'row', flex: 1 }}>
            <TouchableOpacity style={{ fontSize : 24 }} onPress={() => {this.props.navigation.goBack()}}><Text><Icon style={{ fontSize : 10, marginRight: 24, marginTop: 8 }} name="arrow-left" /> Back </Text></TouchableOpacity>
            <Icon name="star" style={{ fontSize : 18, position: 'absolute', right: 0 }}></Icon>
          </View>
        </View>
        <View style={{ height: 160, backgroundColor: '#fff', padding: 16, paddingTop : 0, paddingBottom: 8 }}>
          <View style={{ flexDirection: 'row', flex: 1, borderColor : "#C8CFD6", borderBottomWidth: 0.5, paddingBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 18, marginLeft: 16, fontWeight: "700", flex: 1 }}>{this.state.rest.name}</Text>
              <Text style={{ fontSize: 14, marginLeft: 16, flex: 1 }}>{this.state.rest.location}</Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', flex: 1, borderColor : "#000", borderBottomWidth: 3, marginTop: 16, paddingBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 18, textAlign: 'center', marginLeft: 16, fontWeight: "700", flex: 1 }}><Icon name="star" style={{ fontSize : 18, marginRight : 32 }}></Icon> 4.2 </Text>
              <Text style={{ fontSize: 14, textAlign: 'center', marginLeft: 16, flex: 1 }}>Rating</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 18, textAlign: 'center', marginLeft: 16, fontWeight: "700", flex: 1 }}> {this.state.rest.etd} mins </Text>
              <Text style={{ fontSize: 14, textAlign: 'center', marginLeft: 16, flex: 1 }}>Delivery Time</Text>
            </View>
          </View>
        </View>
        <ScrollView style={{ padding : 16, backgroundColor: '#fff' }}>
            { ( this.state.loading || this.state.error) ||  this.state.cat.map((cat) => { return (
              <View style={{ backgroundColor: '#fff' }}>
                <View style={{ flex: 1, flexDirection : 'row', marginTop : 16}}>
                  <View style={[{ flex: 2}]}>
                    <Text style={[ Fonts.style.h6,  { textAlign : 'left', fontWeight: '700', color: '#555' }]}>{cat.toUpperCase()}</Text>
                  </View> 
                  <View style={{ flex: 2 }} />
                </View>
                <View style={{ flex: 1, flexDirection : 'row', backgroundColor: '#fff' , paddingBottom : 16}}>
                  <View style={[{ flex: 1, borderBottomWidth : 1.5, borderColor : '#ccc'}]}></View> 
                  <View style={{ flex:  6 }} />
                </View>
                <View style={{flex : 1}}>
                  { this.renderMenuItem(cat) }
                </View>
              </View>
            )} )}
        </ScrollView>
        { (this.state.cartItems > 0) &&
        (<TouchableOpacity style={{ backgroundColor: '#fd667b', padding: 16, flexDirection : 'row' }} onPress={this.toggleModal}>
            <Icon name="drawer" style={{ color: '#fff', fontSize : 18, flex:1 }}/>
            <Text  style={{ color: '#fff', fontSize : 18, flex: 4 }}>{this.state.cartItems} Items</Text>
            <Text  style={{ color: '#fff', fontSize : 18, flex: 4, selfAlign: 'right', textAlign: 'right' }}>Rs {this.state.cartCost}</Text>
          </TouchableOpacity>)
        }
        <Modal visible={this.state.showModal} onRequestClose={this.toggleModal}>
          <View style={{ flex: 1, backgroundColor: '#fff'}}>
            <View style={{ backgroundColor: '#fd667b', padding: 16 }}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16}}> Your Cart
              </Text>
              <Icon name="close" style={{ color: '#fff', position: 'absolute', right: 16, fontSize: 16, top: 18}} onPress={this.toggleModal}>
              </Icon>
            </View>
            <ScrollView>
              <View style={{ padding: 16 }}>
                { ( this.state.loading || this.state.error) ||  this.state.cat.map((cat) => { return (
                  <View style={{ backgroundColor: '#fff' }}>
                    <View style={{flex : 1}}>
                      { this.renderMenuItem(cat, 'true') }
                    </View>
                  </View>
                )} )}
              </View>
            </ScrollView>
            <TouchableOpacity style={{ backgroundColor: '#fd667b', padding: 18, width: this.wWidth, alignItems: 'center' }} onPress={this.toggleModalAddress}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 12}}> Next  </Text>
            </TouchableOpacity>
          </View>
        </Modal>
        <Modal
               visible={this.state.showModalAddress}
               onRequestClose={this.toggleModal}>
          <View style={{ flex: 1, backgroundColor: '#fff'}}>
            <View style={{ backgroundColor: '#fd667b', padding: 16 }}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16}}> Your Cart
              </Text>
              <Icon name="close" style={{ color: '#fff', position: 'absolute', right: 16, fontSize: 16, top: 18}} onPress={ this.toggleModalAddress}>
              </Icon>
            </View>
            <ScrollView>
              <View style={{ flex: 1, flexDirection : 'row', marginTop : 32}}>
                  <View style={{ flex: 1 }} />
                  <View style={[{ flex: 2}]}>
                    <Text style={[ Fonts.style.normal,  { textAlign : 'center', color: '#999' }]}>Delivery Details</Text>
                  </View> 
                  <View style={{ flex: 1 }} />
              </View>
              <View style={{ padding: 16 }}>
                <View style={{ flexDirection : 'row'}}>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Name : </Text>
                    <TextInput  underlineColorAndroid="transparent"  style={{ fontSize: 18}} value="Abhinav Dhiman"  />
                  </View>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Phone : </Text>
                    <TextInput  underlineColorAndroid="transparent"  style={{ fontSize: 18}} value="9999999999"  keyboardType="numeric"  />
                  </View>
                </View>
                <View style={{ flexDirection : 'row'}}>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Address : </Text>
                    <TextInput  underlineColorAndroid="transparent"  style={{ fontSize: 18}}  />
                  </View>
                </View>
              </View>
              <View style={{ flex: 1, flexDirection : 'row', marginTop : 8}}>
                  <View style={{ flex: 1 }} />
                  <View style={[{ flex: 2}]}>
                    <Text style={[ Fonts.style.normal,  { textAlign : 'center', color: '#999' }]}>Payment Details</Text>
                  </View> 
                  <View style={{ flex: 1 }} />
              </View>
              <View style={{ padding: 16 }}>
                <View style={{ flexDirection : 'row'}}>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Payment Method : </Text>
                    <Picker
                      style={{ fontSize: 18 }} >
                      <Picker.Item label="Cash On Delivery" value="cod"/>
                      <Picker.Item label="Credit Card / Debit Card" value="card"/>
                      <Picker.Item label="Net Banking" value="nb"/>
                      <Picker.Item label="UPI" value="upi"/>
                    </Picker>
                  </View>
                </View>
              </View>
              <View style={{ flex: 1, flexDirection : 'row', marginTop : 32}}>
                  <View style={{ flex: 1 }} />
                  <View style={[{ flex: 2}]}>
                    <Text style={[ Fonts.style.normal,  { textAlign : 'center', color: '#999' }]}>Order Details</Text>
                  </View> 
                  <View style={{ flex: 1 }} />
              </View>
              <View style={{ padding: 16 }}>
                <View style={{ flexDirection : 'row'}}>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Items : </Text>
                    <Text style={{ fontSize: 18, marginTop: 8, marginLeft: 8}} >{this.state.cartItems}</Text>
                  </View>
                  <View style={{  flex: 1, borderColor: '#ccc', borderWidth: 1, margin: 8, padding: 8}}>
                    <Text>Bill : </Text>
                    <Text style={{ fontSize: 18, marginTop: 8, marginLeft: 8}} >{this.state.cartCost}</Text>
                  </View>
                </View>
              </View>
            </ScrollView>
            <TouchableOpacity style={{ backgroundColor: '#fd667b', padding: 24, width: this.wWidth, alignItems: 'center' }} onPress={this.toggleModalPlaced}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 12}}> Place Order  </Text>
            </TouchableOpacity>
          </View>
        </Modal>
        <Modal
               visible={this.state.showModalPlaced}
               onRequestClose={this.toggleModal}>
          <View style={{ flex: 1, backgroundColor: '#fff'}}>
            <View style={{ backgroundColor: '#fd667b', padding: 16 }}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16}}> Your Cart
              </Text>
            </View>
            <ScrollView>
              <View style={{ flex: 1, flexDirection : 'row', marginTop : 16}}>
                  <View style={{ flex: 1 }} />
                  <View style={[{ flex: 2}]}>
                    <Text style={[ Fonts.style.h6,  { textAlign : 'center', fontWeight: '700', color: '#000' }]}>Your Order Has Been Placed</Text>
                  </View> 
                  <View style={{ flex: 1 }} />
              </View>

            </ScrollView>
            <TouchableOpacity style={{ backgroundColor: '#fd667b', padding: 24, width: this.wWidth, alignItems: 'center' }} onPress={this.closeAllModal}>
              <Text style={{ color: '#fff', fontWeight: '600', fontSize: 12}}> Back  </Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    authtoken : state.login.authToken
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(RestaurantScreen)
