import React, { Component } from 'react'
import { ActivityIndicator, ScrollView, Text, KeyboardAvoidingView, TouchableOpacity, TextInput, Image, View,Modal, Dimensions, AsyncStorage,ImageBackground } from 'react-native'
import { connect } from 'react-redux'
// Add Actions - replace 'Your' with whatever your reducer is called :)
// import YourActions from '../Redux/YourRedux'
import { TopBar } from '../Components/TopBar'
import { Images, Fonts } from '../Themes'
import VendorBox from '../Components/VendorBox'
import Icon from 'react-native-vector-icons/SimpleLineIcons';
// Styles
import styles from './Styles/VendorScreenStyle'
import API from '../Services/Api'
import Loading from '../Components/Loading'


class FlowersCakeGiftsScreen extends Component {

  constructor (props) {
    super(props)
    this.state = {
      longitude: 75.5615718,
      latitude: 26.842223899999997,
      loading: true,
      error: true,
      restData : []
    }
    this.api = API.create()
    this.api.getFCK(this.state.latitude, this.state.longitude).then((result) => {
      let data = result.data;
      console.log(data);
      if (data.status != 200)
        this.setState({loading : false, error: true});
      else{
        this.setState({ loading: false, error : false, restData: data.data });
      }
    });
  }

  componentDidMount(){
    // AsyncStorage.getItem('location').then( (res) => {
    //   if (res != null && res != 'undefined,undefined'){
    //     let loc = res.split(",")
    //     this.setState({ latitude: res[1], longitude : res[2] })
    //     console.log(this.state)
    //   } else {
    //     this.props.navigation.navigate('LocationScreen')
    //   }  
    // }).catch((e) => {
    //   this.props.navigation.navigate('LocationScreen')
    // })
  }

  render () {
    return (
      <View style={{ flex: 1 }}>
          <Loading loading={this.state.loading} />
          <TopBar navigation={this.props.navigation} heading="Order Gifts" search={true}/>
          <View style={{ flexDirection: 'row', height: 64, padding: 8, margin: 8 }}>
            <View style={{ flex: 6, flexDirection: 'row', backgroundColor: "#C8CFD6",padding: 8, paddingTop: 0, paddingBottom: 0, borderRadius : 64, elevation: 1 }}>
              <Icon name="magnifier" style={{ position: 'absolute', fontSize: 18, top: 14, left: 16 }} ></Icon>
              <TextInput underlineColorAndroid="transparent" style={{ flex: 1, fontSize: 16, marginLeft: 32 }} placeholder="Search ..."></TextInput>
              <Icon name="list" style={{ position: 'absolute', fontSize: 18, top: 12, right: 16 }} ></Icon>
            </View>
          </View>
          <ScrollView style={{ flex: 1, flexDirection : 'column', marginBottom: 0 }}>
            {this.state.restData.map((rest) => {
              return <VendorBox navigation={this.props.navigation} data={rest} />
            })}
          </ScrollView>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(FlowersCakeGiftsScreen)
