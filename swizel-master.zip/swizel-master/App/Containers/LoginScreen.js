import React, { Component } from 'react'
import { ScrollView, View, Text, KeyboardAvoidingView, TouchableOpacity, TextInput } from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';
import { connect } from 'react-redux'
import LoginActions from '../Redux/LoginRedux'

import styles from './Styles/LoginScreenStyle'

class LoginScreen extends Component {
  constructor(props){
    super(props)
    this.state = {
      email  : 'dhiman.ahnv@gmail.com',
      password : '9873006779'
    }
    this.isAttempting = false
  }

  handlePressLogin = () => {
    const { email, password } = this.state
    this.isAttempting = true
    this.props.attemptLogin(email, password)
  }

  handleChangeemail = (text) => {
    this.setState({ email: text })
  }

    handleChangePassword = (text) => {
    this.setState({ password: text })
  }

  render () {
    const { email, password } = this.state
    const { fetching } = this.props
    const editable = !fetching
    const textInputStyle = editable ? styles.textInput : styles.textInputReadonly
    return (
      <ScrollView style={{ backgroundColor : '#f9f9f9', flex: 1 }}>
          <View style={{ backgroundColor : '#ccc', height: 300 }}>
            <TouchableOpacity style={{ marginTop: 16, marginLeft : 16, flexDirection: 'row' }}>
              <Icon name="plus" style={{ color : '#fff', marginRight: 4, marginTop: 1, fontSize: 16 }} />
              <Text style={{ color : '#fff' }}> Create Account </Text>
            </TouchableOpacity>
          </View>
          <View style={{ flex : 1 }}>
            <View style={{ flex :1 ,margin: 32 }}>
              <TouchableOpacity style={{ padding : 16, backgroundColor: '#3b5998', marginBottom: 8, flexDirection: 'row', borderRadius: 64 }}>
                <Icon name="facebook"  style={{ color : '#fff', marginRight: 16, fontSize: 18 }}/><Text style={{ color : '#fff' }}> Login with Facebook </Text>
              </TouchableOpacity>
              <TouchableOpacity style={{ padding : 16, backgroundColor: '#dd4b39', marginBottom: 8, flexDirection: 'row', borderRadius: 64 }}>
                <Icon name="google"  style={{ color : '#fff', marginRight: 16, fontSize: 18 }}/><Text style={{ color : '#fff' }}> Login with Google </Text>
              </TouchableOpacity>
              <Text style={{ textAlign: 'center', marginTop : 8, marginBottom: 12 }} >OR</Text>
              <View style={{ padding: 8,  backgroundColor : '#fff', borderWidth: 1, borderColor: '#d3d3d3' }}>
                <TextInput underlineColorAndroid="transparent" ref='email'
              style={textInputStyle}
              value={email}
              editable={editable}
              keyboardType='default'
              returnKeyType='next'
              autoCapitalize='none'
              autoCorrect={false}
              onChangeText={this.handleChangeemail}
              underlineColorAndroid='transparent'
              onSubmitEditing={() => this.refs.password.focus()}
              placeholder='Email'/>
              </View>
              <View style={{ padding: 8,  backgroundColor : '#fff', borderWidth: 1, borderColor: '#d3d3d3' }}>
                <TextInput underlineColorAndroid="transparent" ref='password'
              style={textInputStyle}
              value={password}
              editable={editable}
              keyboardType='default'
              returnKeyType='go'
              autoCapitalize='none'
              autoCorrect={false}
              secureTextEntry
              onChangeText={this.handleChangePassword}
              underlineColorAndroid='transparent'
              onSubmitEditing={this.handlePressLogin}
              placeholder='Password'/>
              </View>
              <TouchableOpacity style={{ padding : 16, marginTop: 8, backgroundColor: '#4285f4', marginBottom: 8, flexDirection: 'row', borderRadius: 64 }} onPress={this.handlePressLogin}>
                <Text style={{ color : '#fff', textAlign: 'center', flex : 1 }}> Sign In </Text>
              </TouchableOpacity>
            </View>
          </View>
      </ScrollView>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    fetching : state.login.fetching
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    attemptLogin: (email, password) => dispatch(LoginActions.loginRequest(email,password))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginScreen)
