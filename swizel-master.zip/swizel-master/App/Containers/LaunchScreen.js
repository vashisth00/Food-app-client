import React, { Component } from 'react'
import { ImageBackground, Text, TouchableHighlight } from 'react-native'
import { Images } from '../Themes'
import { connect } from 'react-redux'
import { LoginActions } from '../Redux/LoginRedux'

// Styles
import styles from './Styles/LaunchScreenStyles'

class LaunchScreen extends Component {
  constructor(props){
    super(props)
    if (this.props.authtoken){
      this.props.navigation.navigate("HomeScreen")
    }
  }
  render () {
    return (
      <ImageBackground source={Images.background} style={{ flex: 1, backgroundColor: '#fff', alignItems : 'flex-end', flexDirection : 'row' }}>
        <TouchableHighlight style={ { height: 64, flex: 1, padding : 32, paddingTop : 16 , backgroundColor: '#ff4550', elevation: 2 } } onPress={() => {this.props.navigation.navigate('LoginScreen')}}>
          <Text style={{ textAlign: 'center', fontSize: 18, lineHeight: 32, color : '#fff' }}> Let's Get Started </Text>
        </TouchableHighlight>
      </ImageBackground>
    )
  }
}


const mapStateToProps = (state) => {
  return {
    authtoken : state.login.authToken 
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(LaunchScreen)
