import React, { Component } from 'react'
import { View, Text, KeyboardAvoidingView, Image, ScrollView, TouchableOpacity } from 'react-native'
import { connect } from 'react-redux'
import BottomNavigation, { Tab } from 'react-native-material-bottom-navigation'
import Icon from 'react-native-vector-icons/SimpleLineIcons';
import { TopBar } from '../Components/TopBar'
import API from '../Services/Api'
import { Images, Fonts } from '../Themes'
import { LoginActions } from '../Redux/LoginRedux'

// Styles
import styles from './Styles/ProfileScreenStyle'

class ProfileScreen extends Component {
  constructor (props) {
    super(props)
    this.state = {
      user : [],
      orders : []
    }
    this.api = API.create()
    this.api.getUser(this.props.authtoken).then((res) => {
      if (res.data.status == 200){
        this.setState({ user : res.data.data[0] })
      }
    })
    this.api.getOrders(this.props.authtoken).then((res) => {
      if (res.data.status == 200){
        this.setState({ orders : res.data.data })
      }
    })
  }
  render () {
    return (
      <View>
        <TopBar navigation={this.props.navigation} heading="Your Profile" />
        <View style={{ flexDirection : 'row', padding: 32, backgroundColor: '#fff', height: 128 }}>
          <View style={{ marginRight: 16, height: 128 }}>
            <Image source={{ uri: this.state.user.picture}} style={{ height: 64, width: 64 }} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ lineHeight: 18, marginLeft: 16, fontWeight: "700", flex: 1 }}>{ this.state.user.name }</Text>
            <Text style={{ lineHeight: 18, marginLeft: 16, fontWeight: "400", flex: 1 }}>{ this.state.user.email }</Text>
            <Text style={{ lineHeight: 18, marginLeft: 16, fontWeight: "400", flex: 1 }}>{ this.state.user.phno }</Text>
          </View>
        </View>
        <ScrollView>
          {
            this.state.orders.map((order) => {
              return (<View style={{backgroundColor : '#fff', padding: 16, paddingTop: 24, paddingLeft : 52, borderTopWidth: 1, borderBottomWidth : 1, borderColor : "#d3d3d3"}}>
            <Icon name="cup" style={{ color: '#fe5b3c', position: 'absolute', top : 21, left : 16, fontSize : 24 } }/> 
            <View style={{flex: 1, flexDirection : 'row'}}>
              <View style={{ flex : 3 }}>
                <Text style={[ Fonts.style.normal,{ fontWeight: '400', color: "#000" }]} > { order.restaurant }</Text>
                {
                  order.items.map((item) => { return (
                    <Text style={[ Fonts.style.description ]} > • {item.item} / {item.name} x {item.qty} </Text>    
                  )
                  })
                }
                <Text style={[ Fonts.style.description ]} > </Text>
                <Text style={[ Fonts.style.description ]} >Total Amount  :  Rs. {order.bill} </Text>
              </View>
              <View style={{ flex: 1, paddingTop: 0 }}>
                <View style={{ flex : 1, alignItems : 'flex-end' }}>
                {
                  order.status == 0 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#03a9f3', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 1 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#03a9f3', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 2 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#fec107', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 3 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#00c292', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 4 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#00c292', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 5 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#00c292', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                {
                  order.status == 6 && 
                  <Text style={ [Fonts.style.h6 , { fontSize: 12, backgroundColor: '#fb9678', color: '#fff', padding: 8, borderRadius: 64 }] }> Delivered </Text>
                }
                </View>
              </View>
            </View>
          </View>  )
            })
          }
          
        </ScrollView>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    authtoken : state.login.authToken 
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileScreen)
