import React, { Component } from 'react'
import { View } from 'react-native'

import styles from './Styles/LoadingScreenStyle'

class LoadingScreen extends Component {
  render () {
    return (
      <View style={styles.container} />
    )
  }
}

export default LoadingScreen
