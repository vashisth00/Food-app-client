import React, { Component } from 'react'
import { View, Text, KeyboardAvoidingView, Image, Button, PermissionsAndroid, AsyncStorage } from 'react-native'
import RoundedButton from '../../App/Components/RoundedButton'
import { connect } from 'react-redux'
import Permissions from '../Lib/permissions'
// import LocationActions, { isLocationSet } from '../Redux/LocationRedux'
// Add Actions - replace 'Your' with whatever your reducer is called :)
// import YourActions from '../Redux/YourRedux'

// Styles
import styles from './Styles/LocationScreenStyle'
import { Fonts, Images } from '../Themes'

class LocationScreen extends Component {
  constructor (props) {
    super(props)
    this.props = props
    this.state = {
      location : {
        latitude : null,
        longitude : null 
      }
    }
    this.getGPSLocation = this.getGPSLocation.bind(this)
    this.locationConfirmed = this.locationConfirmed.bind(this)
  }
  
  async getGPSLocation(){
    Permissions.check('location').then((response) => {
      if (response == 'authorized'){
        navigator.geolocation.getCurrentPosition(
          (position) => {
            this.setState({ location : { latitude : position.coords.latitude, longitude : position.coords.longitude } })
            this.props.updateLocation(this.state.location)
            return true;
          }
        )
      } else {
        return false
      }
    }).catch((err) => {
      console.log(err)
      return false
    });
  }

  locationConfirmed(){
    this.getGPSLocation().then(() => {
      if (this.state.location.latitude == false && this.state.location.latitude == false){
        alert("Cannot Proceed Without Location")
      } else {
        console.log("Redirected to HomeScreen");
        this.props.navigation.navigate('HomeScreen')
      }
    })
  }

  render () {
    return (
      <View style={styles.location}>
        <KeyboardAvoidingView behavior='position'>
          <Text style={ [Fonts.style.h3, styles.heading] }>
          Choose your location
          </Text>
          <Image source={Images.map} style={{ width: 256, height: 256, alignSelf: 'center' }}/>
          <Text style={ [ Fonts.style.normal, { textAlign: 'center', color: 'white', padding: 32 } ] }>{`Please Turn on your location services to know the Delivery Area.`}</Text>
          <RoundedButton style={{ backgroundColor: '#0a55bd' , marginTop: 16}} onPress={this.locationConfirmed}>Use my GPS Location</RoundedButton>
          <Text style={ [ Fonts.style.normal, { textAlign: 'center', color: 'white', padding: 32 } ] }>{`Or manually enter your address below`}</Text>
          <RoundedButton style={{ backgroundColor: '#4a9afa' }} onPress={() => {this.props.navigation.navigate('LocationMapScreen')}}>Enter Location Manually</RoundedButton>
        </KeyboardAvoidingView>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    // location : state.location
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    // updateLocation : (location) => dispatch(LocationActions.locationUpdate(location)),
    // getLocation: () => dispatch(LocationActions.locationGet())
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(LocationScreen)
