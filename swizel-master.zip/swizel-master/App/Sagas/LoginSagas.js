import { call, put } from 'redux-saga/effects'
import { path } from 'ramda'
import LoginActions from '../Redux/LoginRedux'

export function * login (api, { username, password }) {
  const response = yield call(api.loginUsingEmail, username, password)
  if (response.ok){
	const data = path(['data'], response)
	if (data.status == 202){
		yield put(LoginActions.loginSuccess(data.data.auth_token))
	} else {
		yield put(LoginActions.loginFailure(data.data))	
	}
  }
}
