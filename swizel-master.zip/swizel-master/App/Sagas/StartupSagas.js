import { put, select } from 'redux-saga/effects'
import { is } from 'ramda'
import AppStateActions, { isFirstLaunch } from '../Redux/AppStateRedux'
import LoggedInActions, { isLoggedIn } from '../Redux/LoginRedux'

export const selectFirstLaunchStatus = (state) => isFirstLaunch(state.appState)
export const selectLoggedInStatus = (state) => isLoggedIn(state.login)

export function * startup (action) {
  const isFirstLaunch = yield select(selectFirstLaunchStatus)
  if (isFirstLaunch == undefined || isFirstLaunch){
  	yield put(AppStateActions.firstLaunch())
  }
  const isLoggedIn = yield select(selectLoggedInStatus)
  if (isLoggedIn) {
    yield put(LoggedInActions.autoLogin())
  }
}
